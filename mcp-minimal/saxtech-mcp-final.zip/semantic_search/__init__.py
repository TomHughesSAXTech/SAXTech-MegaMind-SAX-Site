import azure.functions as func
import json
import requests
import re
from urllib.parse import urlparse

# Azure Search configuration
SEARCH_ENDPOINT = 'https://saxmegamind-search.search.windows.net'
API_KEY = 'sZf5MvolOU8wqcM0sb1jI8XhICcOrTCfSIRl44vLmMAzSeA34CDO'
API_VERSION = '2023-11-01'
INDEX_NAME = 'sop-documents'
SEMANTIC_CONFIG = 'sop-semantic-config'

def format_search_results(results):
    """Format search results for optimal AI consumption"""
    if not results or not isinstance(results, list):
        return []
    
    formatted_results = []
    
    for index, result in enumerate(results):
        # Clean and format content
        content = result.get('content', '')
        content = re.sub(r'\r\n', '\n', content)
        content = re.sub(r'\n\n+', '\n\n', content)
        content = re.sub(r'\s+', ' ', content)
        content = content.strip()
        
        # Determine best source URL
        source_url = result.get('url') or result.get('blobUrl', '')
        source_domain = 'SAX Document'
        
        if source_url:
            try:
                parsed_url = urlparse(source_url)
                source_domain = parsed_url.hostname.replace('www.', '') if parsed_url.hostname else 'SAX Document'
            except:
                source_domain = 'SAX Document'
        
        # Format title
        title = result.get('title', 'SAX Policy Document')
        
        # Extract highlights if available
        highlights = result.get('@search.highlights', {})
        
        # Create rich formatted result
        formatted_result = {
            'rank': index + 1,
            'title': title,
            'content': content,
            'sourceUrl': source_url,
            'sourceDomain': source_domain,
            'score': result.get('@search.score', 0),
            'highlights': highlights,
            'hasMore': len(content) > 1500,
            'contentLength': len(content),
            'contentPreview': content[:500] + ('...' if len(content) > 500 else ''),
            'searchMetadata': {
                'searchScore': result.get('@search.score', 0),
                'searchRank': index + 1
            }
        }
        
        formatted_results.append(formatted_result)
    
    return formatted_results

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Parse request body
        query = ''
        
        if req.method == 'POST':
            try:
                req_body = req.get_json()
                query = req_body.get('query', '') if req_body else ''
            except ValueError:
                pass
        
        if not query:
            query = req.params.get('query', '')
        
        if not query:
            return func.HttpResponse(
                json.dumps({
                    'success': False,
                    'error': 'Query parameter required',
                    'message': 'Please provide a search query'
                }),
                status_code=400,
                headers={'Content-Type': 'application/json'}
            )

        # Construct Azure Search request
        search_url = f'{SEARCH_ENDPOINT}/indexes/{INDEX_NAME}/docs/search'
        search_body = {
            'search': query,
            'queryType': 'semantic',
            'semanticConfiguration': SEMANTIC_CONFIG,
            'select': 'title,content,blobUrl,url,source',
            'top': 10,
            'highlight': 'title,content',
            'highlightPreTag': '<mark>',
            'highlightPostTag': '</mark>'
        }
        
        headers = {
            'api-key': API_KEY,
            'Content-Type': 'application/json'
        }
        
        params = {
            'api-version': API_VERSION
        }
        
        # Execute search
        response = requests.post(search_url, json=search_body, headers=headers, params=params)
        response.raise_for_status()
        
        search_results = response.json()
        
        # Format results for optimal consumption
        formatted_results = format_search_results(search_results.get('value', []))
        
        # Create comprehensive response
        result_response = {
            'success': True,
            'query': query,
            'index': INDEX_NAME,
            'totalResults': len(formatted_results),
            'results': formatted_results,
            'searchMetadata': {
                'queryType': 'semantic',
                'semanticConfig': SEMANTIC_CONFIG,
                'endpoint': SEARCH_ENDPOINT
            },
            'api': {
                'version': API_VERSION,
                'function': 'semantic-search'
            }
        }
        
        return func.HttpResponse(
            json.dumps(result_response, ensure_ascii=False, indent=2),
            status_code=200,
            headers={
                'Content-Type': 'application/json; charset=utf-8',
                'Access-Control-Allow-Origin': '*'
            }
        )
        
    except requests.exceptions.RequestException as e:
        return func.HttpResponse(
            json.dumps({
                'success': False,
                'error': 'Search API failed',
                'message': str(e),
                'query': query
            }),
            status_code=500,
            headers={'Content-Type': 'application/json'}
        )
        
    except Exception as e:
        return func.HttpResponse(
            json.dumps({
                'success': False,
                'error': 'Search failed',
                'message': str(e),
                'query': query
            }),
            status_code=500,
            headers={'Content-Type': 'application/json'}
        )