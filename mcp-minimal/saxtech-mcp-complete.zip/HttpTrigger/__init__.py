import azure.functions as func
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps({"message": "Python function works!"}),
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )