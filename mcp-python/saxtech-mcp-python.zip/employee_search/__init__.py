import logging
import azure.functions as func
import json
import requests
import msal
from typing import List, Dict, Optional

# Microsoft Graph configuration
TENANT_IDS = [
    'a33e9b66-a6ef-43bf-9702-7cb4301d0a16',  # saxadvisorygroup.com (primary)
    '3d659328-eef0-44f7-8481-5833e1051aec',  # saxtechnology.com
    '3ac3dcb3-43bd-446e-a396-22969036227e'   # saxwa.com
]

CLIENT_ID = '0798c418-d08f-4c40-9a72-3be02870e152'
CLIENT_SECRET = 'i7W8Q~PqLdXFeqB2nHM5HXUSnEmUo1dh8ulTcbGu'

TENANT_INFO = [
    {'id': TENANT_IDS[0], 'domain': 'saxadvisorygroup.com'},
    {'id': TENANT_IDS[1], 'domain': 'saxtechnology.com'},
    {'id': TENANT_IDS[2], 'domain': 'saxwa.com'}
]

def get_access_token(tenant_id: str) -> Optional[str]:
    """Get access token for Microsoft Graph"""
    try:
        app = msal.ConfidentialClientApplication(
            CLIENT_ID,
            authority=f"https://login.microsoftonline.com/{tenant_id}",
            client_credential=CLIENT_SECRET
        )
        
        result = app.acquire_token_silent(['https://graph.microsoft.com/.default'], account=None)
        
        if not result:
            result = app.acquire_token_for_client(scopes=['https://graph.microsoft.com/.default'])
        
        if 'access_token' in result:
            return result['access_token']
        else:
            logging.error(f"Token acquisition failed for tenant {tenant_id}: {result.get('error_description', 'Unknown error')}")
            return None
            
    except Exception as e:
        logging.error(f"Token acquisition failed for tenant {tenant_id}: {str(e)}")
        return None

def search_employees_in_tenant(query: str, tenant_id: str, tenant_domain: str) -> List[Dict]:
    """Search employees in a specific tenant"""
    try:
        access_token = get_access_token(tenant_id)
        if not access_token:
            logging.warning(f"Could not get access token for tenant {tenant_id}")
            return []
        
        search_url = 'https://graph.microsoft.com/v1.0/users'
        
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        params = {
            '$filter': f"startswith(displayName,'{query}') or startswith(givenName,'{query}') or startswith(surname,'{query}') or startswith(jobTitle,'{query}') or startswith(department,'{query}')",
            '$select': 'id,displayName,givenName,surname,jobTitle,department,companyName,mail,mobilePhone,businessPhones,officeLocation,manager',
            '$top': 20
        }
        
        response = requests.get(search_url, headers=headers, params=params)
        response.raise_for_status()
        
        users = response.json().get('value', [])
        
        # Format users with enhanced cross-tenant information
        formatted_users = []
        for user in users:
            base_email = user.get('mail', '').split('@')[0] if user.get('mail') else ''
            
            formatted_user = {
                'id': user.get('id'),
                'name': user.get('displayName', 'Unknown'),
                'firstName': user.get('givenName', ''),
                'lastName': user.get('surname', ''),
                'title': user.get('jobTitle', ''),
                'department': user.get('department', ''),
                'company': user.get('companyName', ''),
                'email': user.get('mail', ''),
                'phone': user.get('businessPhones', [''])[0] if user.get('businessPhones') else '',
                'mobile': user.get('mobilePhone', ''),
                'location': user.get('officeLocation', ''),
                'tenantId': tenant_id,
                'primaryDomain': tenant_domain,
                'allTenants': ['saxadvisorygroup.com', 'saxtechnology.com', 'saxwa.com'],
                'additionalEmails': [
                    f"{base_email}@saxadvisorygroup.com",
                    f"{base_email}@saxtechnology.com", 
                    f"{base_email}@saxwa.com"
                ] if base_email else []
            }
            
            formatted_users.append(formatted_user)
            
        return formatted_users
        
    except requests.exceptions.RequestException as e:
        logging.error(f"Search failed in tenant {tenant_id}: {str(e)}")
        return []
    except Exception as e:
        logging.error(f"Unexpected error in tenant {tenant_id}: {str(e)}")
        return []

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Employee search request received')

    try:
        # Parse request
        query = ''
        
        if req.method == 'POST':
            try:
                req_body = req.get_json()
                query = req_body.get('query', '') if req_body else ''
            except ValueError:
                pass
                
        if not query:
            query = req.params.get('query', '')

        if not query:
            return func.HttpResponse(
                json.dumps({
                    'success': False,
                    'error': 'Query parameter required',
                    'message': 'Please provide a search query'
                }),
                status_code=400,
                headers={'Content-Type': 'application/json'}
            )

        logging.info(f'Searching for employee: "{query}"')

        # Search across all tenants concurrently
        all_employees = []
        search_results = {}
        
        for tenant in TENANT_INFO:
            logging.info(f'Searching in tenant: {tenant["domain"]}')
            employees = search_employees_in_tenant(query, tenant['id'], tenant['domain'])
            all_employees.extend(employees)
            search_results[tenant['domain']] = len(employees)

        # Remove duplicates based on name (case-insensitive)
        unique_employees = []
        seen_names = set()

        for employee in all_employees:
            name_key = employee['name'].lower()
            if name_key not in seen_names:
                seen_names.add(name_key)
                unique_employees.append(employee)

        # Create comprehensive response
        response_data = {
            'success': True,
            'query': query,
            'count': len(unique_employees),
            'results': unique_employees,
            'searchMetadata': {
                'tenantsSearched': len(TENANT_INFO),
                'tenantResults': search_results,
                'totalMatches': len(all_employees),
                'uniqueMatches': len(unique_employees),
                'crossTenantSync': True
            },
            'api': {
                'function': 'employee-search',
                'timestamp': func.datetime.utcnow().isoformat() + 'Z',
                'tenants': [t['domain'] for t in TENANT_INFO]
            }
        }

        logging.info(f'Employee search completed. Found {len(unique_employees)} unique results across {len(TENANT_INFO)} tenants')

        return func.HttpResponse(
            json.dumps(response_data, ensure_ascii=False, indent=2),
            status_code=200,
            headers={
                'Content-Type': 'application/json; charset=utf-8',
                'Access-Control-Allow-Origin': '*'
            }
        )

    except Exception as e:
        logging.error(f'Employee search error: {str(e)}')
        return func.HttpResponse(
            json.dumps({
                'success': False,
                'error': 'Employee search failed',
                'message': str(e),
                'query': query if 'query' in locals() else 'unknown'
            }),
            status_code=500,
            headers={'Content-Type': 'application/json'}
        )