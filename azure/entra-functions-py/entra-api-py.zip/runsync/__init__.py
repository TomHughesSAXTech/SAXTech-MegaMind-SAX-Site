import json
import uuid
import azure.functions as func

CORS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "*",
    "Content-Type": "application/json"
}

def main(req: func.HttpRequest) -> func.HttpResponse:
    if req.method == 'OPTIONS':
        return func.HttpResponse(status_code=204, headers=CORS)

    job_id = str(uuid.uuid4())
    payload = {"status": "queued", "id": job_id, "received": None}
    try:
        payload["received"] = req.get_json()
    except ValueError:
        payload["received"] = None

    return func.HttpResponse(json.dumps(payload), headers=CORS, status_code=202)
