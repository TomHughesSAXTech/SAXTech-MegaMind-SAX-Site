import json
import os
import urllib.request
import azure.functions as func

CORS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "*",
    "Content-Type": "application/json"
}

def main(req: func.HttpRequest) -> func.HttpResponse:
    if req.method == 'OPTIONS':
        return func.HttpResponse(status_code=204, headers=CORS)

    endpoint = os.environ.get('SEARCH_ENDPOINT')
    api_key = os.environ.get('SEARCH_API_KEY')
    api_version = os.environ.get('SEARCH_API_VERSION', '2023-11-01')

    if not endpoint or not api_key:
        return func.HttpResponse(
            json.dumps({"error": "Search service not configured"}),
            headers=CORS,
            status_code=503,
        )

    try:
        body = req.get_json()
    except ValueError:
        body = {}

    index_name = body.get('indexName') or body.get('index') or body.get('index_name')
    if not index_name:
        return func.HttpResponse(
            json.dumps({"error": "indexName is required"}),
            headers=CORS,
            status_code=400,
        )

    url = f"{endpoint.rstrip('/')}/indexes/{urllib.parse.quote(index_name)}/docs/search?api-version={urllib.parse.quote(api_version)}"

    search_body = {
        "search": body.get("search", "*"),
        "top": body.get("top", 5),
        "count": body.get("count", True),
        "select": body.get("select"),
        "filter": body.get("filter"),
        "orderby": body.get("orderby"),
    }

    req_obj = urllib.request.Request(url, data=json.dumps(search_body).encode('utf-8'), method='POST')
    req_obj.add_header('Content-Type', 'application/json')
    req_obj.add_header('api-key', api_key)

    try:
        with urllib.request.urlopen(req_obj) as resp:
            resp_text = resp.read().decode('utf-8')
            try:
                data = json.loads(resp_text)
            except Exception:
                data = {"raw": resp_text}
            status = resp.getcode()
    except Exception as e:
        return func.HttpResponse(
            json.dumps({"error": "Proxy error", "detail": str(e)}),
            headers=CORS,
            status_code=500,
        )

    return func.HttpResponse(json.dumps({"status": status, "ok": 200 <= status < 300, "data": data}), headers=CORS, status_code=200 if 200 <= status < 300 else status)
