import json
import os
import sys
import datetime
import azure.functions as func

CORS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "*",
    "Content-Type": "application/json"
}

def main(req: func.HttpRequest) -> func.HttpResponse:
    if req.method == 'OPTIONS':
        return func.HttpResponse(status_code=204, headers=CORS)

    payload = {
        "ok": True,
        "service": "entra-api",
        "time": datetime.datetime.utcnow().isoformat() + 'Z',
        "env": {
            "python": sys.version,
            "site": os.environ.get('WEBSITE_SITE_NAME')
        }
    }
    return func.HttpResponse(json.dumps(payload), headers=CORS, status_code=200)
